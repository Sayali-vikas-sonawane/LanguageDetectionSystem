from _hpy_universal import *
from _hpy_universal import _debug
